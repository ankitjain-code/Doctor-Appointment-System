


necessary software:

1. jdk(java development kit)
2. apache tomcat web server
3. any IDE to run and view the project.



html files

1.index
2.login
3.registration

.java files(servlets)

1. doctor select
2. date select
3. description
4. confirm booking
5. login
6. logout
7. viewappointment
8. cancel appointment
9. registerpatient



connectors:
1.odbc14.jar
2.servlet-api


how to run in eclipse

1.Go to File -> Import. The following dialog will appear.

2.Select Existing Projects into Workspace.
NOTE: It may seem counter-intuitive to not be selecting Archive File at this step. The Archive File option is used for importing Eclipse resources into an existing Eclipse project. Since you are importing an entire project, you must select Existing projects.

3.Click the radio button next to Select archive file and click the Browse button on the following dialog.

4.Find the archive file on your hard disk. Click Open to select it.
If you have selected an archive file containing an entire Eclipse project, the project name will appear in the box below, already checked. Click Finish to perform the import. 

5.Congratulations, the project should now appear in your Project Explorer view!